package com.a.shon.scoutszone2.enums;

public enum ZoneType
{
    Inside, Outside, Inside_a_room
}
