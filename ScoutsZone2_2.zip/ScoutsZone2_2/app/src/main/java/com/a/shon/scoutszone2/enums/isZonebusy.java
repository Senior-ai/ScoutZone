package com.a.shon.scoutszone2.enums;

public enum isZonebusy {
    Busy, Available, Halfbusy
}
