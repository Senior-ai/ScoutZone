package com.a.shon.scoutszone2.enums;

public enum RoleType {
    ד, ה, ו, ז, ח, חמישיות, צמיד, ראשצ, א_פעילים, מרכז, בוגר
}
