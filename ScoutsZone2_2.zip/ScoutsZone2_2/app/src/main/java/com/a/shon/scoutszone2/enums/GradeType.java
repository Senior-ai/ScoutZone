package com.a.shon.scoutszone2.enums;

public enum GradeType {
    קורס, י, יא, יב, בוגר
}
